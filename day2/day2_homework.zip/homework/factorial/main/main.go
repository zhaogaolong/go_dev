package main

import (
	"fmt"
)

func factorial(number int) int {
	result := 1
	for i := 2; i <= number; i++ {
		result = result * i

	}
	fmt.Printf("%d 的阶乘是：%d\n", number, result)
	return result
}

func main() {
	factorial(10)
}
