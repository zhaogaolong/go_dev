package main

import (
	"fmt"
	"strconv"
)

func add(str1, str2 string) {
	var (
		num1   int
		num2   int
		sumTmp int
		sumStr string
	)
	str1Long := len(str1)
	str2Long := len(str2)
	num1, _ = strconv.Atoi(string(str1[(str1Long - 1)]))
	num2, _ = strconv.Atoi(string(str2[(str2Long - 1)]))

	sumTmp = num1 + num2
	fmt.Println(num1, num2, sumTmp)
	if sumTmp <= 9 {
		sumStr = fmt.Sprintf("%d", sumTmp)
	} else {
		// 说明结果是单数
		sumStr = fmt.Sprintf("%d", sumTmp)
		for {

		}

	}

	// split string
	// str1 = str1[0:52]
	fmt.Println(str1)
}

func main() {
	num1 := "896"
	num2 := "834"
	add(num1, num2)
}
